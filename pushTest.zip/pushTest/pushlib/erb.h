//
//  erb.h
//  TITANLIB_V2
//
//  Created by komj on 14. 3. 19..
//  Copyright (c) 2014년 에이치투오시스템테크놀로지(주). All rights reserved.
//

#ifndef TITANLIB_V2_erb_h
#define TITANLIB_V2_erb_h

/* //{{ leesb 20140210 : define 추가 */
#define FREE_NULL(var)  if ( var ) { free( var ); var= NULL; }

#endif
