//
//  AppDelegate.h
//  pushTest
//
//  Created by komj on 2015. 3. 12..
//  Copyright (c) 2015년 H2OSystech. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DataManager;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSString *window;
    NSString *token;
    NSString *string;
    DataManager  *_dataManager;
    
}

@property (nonatomic, strong) NSString *pushTokenID;
@property (strong, nonatomic) NSString *token;
@property (strong, nonatomic) NSString *string;
@property (strong, nonatomic) UIWindow *window;

+ (AppDelegate *)appDelegate;

@end

