//
//  ViewController.m
//  pushTest
//
//  Created by komj on 2015. 3. 12..
//  Copyright (c) 2015년 H2OSystech. All rights reserved.
//

#import "ViewController.h"

#include "erbapi.h"
#include "DataManager.h"

@interface ViewController ()

@end

@implementation ViewController

static DataManager *dataManager = nil;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    dataManager = [DataManager sharedPCDataManager];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pushRegist:(id)sender
{
    if( [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] || [[UIDevice currentDevice].model isEqualToString:@"iPad Simulator"] ){
        [DataManager sharedPCDataManager].deviceUUID = [[UIDevice currentDevice].identifierForVendor UUIDString];
    }
    else{
        [DataManager sharedPCDataManager].deviceUUID = [AppDelegate appDelegate].pushTokenID;
    }
    
    int rtn;
    /*
    const char *token = [dataManager.deviceUUID UTF8String];
    
    if(token == NULL)
    {
        token = "testtoken";
    }
     */
    const char *token = "testtoken";
    
    
    NSString *multi = @"Y";
    /*
    "N" : 중복접속 사용안함
     - 동일한 ID로 기존에 등록된 기기가 있으면 추가 등록 불가 return 3 발생
    "Y" : 중복접속 사용
     - 동일한 ID로 등록된 기기가 있어도 추가 등록
    "D" : 중복접속 사용안함
     - 동일한 ID로 기존에 등록된 기기가 있으면 모두 삭제 후 요청한 신규 기기만 등록
     */

    //rtn = pushRegist("114.205.98.48", 6101, "komj", (char *)token, "com.h2osystech.iMeritzService", (char *)[multi UTF8String], 10);
    rtn = pushRegist("211.255.202.76", 3101, "komj", (char *)token, "com.h2osystech.iMeritzService", (char *)[multi UTF8String], 10);
//    rtn = pushRegist("192.168.3.172", 3101, "komj", (char *)token, "com.h2osystech.iMeritzService", (char *)[multi UTF8String], 10);
    
    NSLog(@"pushRegist (%d), (%@)", rtn, dataManager.deviceUUID);
    if(rtn <= 0)
    {
        NSLog(@"pushRegist 실패 rtn(%d)", rtn);
    }
    else if(rtn == 3)
    {
        NSLog(@"등록된 기기가 존재합니다.");
    }
    else if(rtn == 7)
    {
        NSLog(@"중복접속이 허용되지 않았습니다.");
    }
    else
    {
        NSLog(@"pushRegist 성공");
    }
}

- (IBAction)pushUnRegist:(id)sender
{
    int rtn;
    
    rtn = pushUnRegist("211.255.202.76", 3101, "komj", "deviceToken", "com.h2osystech.iMeritzService", 10);
    
    if(rtn <= 0)
    {
        NSLog(@"push unRegist (%d)", rtn);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"pushUnRegist 실패" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
    }
    else
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"pushUnRegist 성공" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
    }
}

- (IBAction)pushReceipt:(id)sender
{
    int rtn;
    
    rtn = pushReceipt("211.255.202.76", 3101, "komj",  "201603220000082470", 10);
    
    if(rtn <= 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"pushReceipt 실패" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"pushReceipt 성공" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
    }
}

- (IBAction)pushGetMsg:(id)sender
{
    int rtn;
    
    DATA *msg = NULL;
    
//    rtn = pushGetMsgAll("211.255.202.76", 3101, "komj", "com.h2osystech.iMeritzService", 100, 10, &msg);
    rtn = pushGetMsg("211.255.202.76", 3101, "komj","com.h2osystech.iMeritzService", 10, &msg);
    if(rtn < 0)
    {
        NSLog(@"getMsg(%d)", rtn);
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"pushGetMsg 실패" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
//        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];

    }
    else if(rtn == 0)
    {
        NSLog(@"getMsg(%d)", rtn);
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"미수신 메시지가 없습니다." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
//        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];

    }
    else
    {
        int cnt = rtn;
        
        char    RECEIVER_ID     [32 + 1];
        char    SENDER_ID       [32 + 1];
        char    TIMEATAMP       [20 + 1];
        char    TASK_GB         [32 + 1];
        char    MSG_TITLE       [100+ 1];
        char    NOTI_TYPE       [1  + 1];
        char    LINK_GB         [1  + 1];
        char    LINK_URL        [128+ 1];
        char    ATTACHFILE_CNT  [1  + 1];
        char    ATTACHFILE_LEN  [4  + 1];
        char    ATTACHFILE_URL  [4000+1];
        char    MSG_LEN         [8  + 1];
        char    *MSG_CTT = NULL;
        int     pos = 0;
        int     mLen = 0;
        
        NSLog(@"cnt[%d]", cnt);
        for(int i=0; i<cnt; i++)
        {
            NSLog(@"MSGID[%s]", msg[i].msgid);
            NSLog(@"MSGLen[%d]", msg[i].msgLen);
            NSLog(@"MSG[%s]", msg[i].msg);

/*데이터저장 버퍼 초기화*/
            memset(RECEIVER_ID,     0x00,   sizeof(RECEIVER_ID));
            memset(SENDER_ID,       0x00,   sizeof(SENDER_ID));
            memset(TIMEATAMP,       0x00,   sizeof(TIMEATAMP));
            memset(TASK_GB,         0x00,   sizeof(TASK_GB));
            memset(MSG_TITLE,       0x00,   sizeof(MSG_TITLE));
            memset(NOTI_TYPE,       0x00,   sizeof(NOTI_TYPE));
            memset(LINK_GB,         0x00,   sizeof(LINK_GB));
            memset(LINK_URL,        0x00,   sizeof(LINK_URL));
            memset(ATTACHFILE_CNT,  0x00,   sizeof(ATTACHFILE_CNT));
            memset(ATTACHFILE_LEN,  0x00,   sizeof(ATTACHFILE_LEN));
            memset(ATTACHFILE_URL,  0x00,   sizeof(ATTACHFILE_URL));
            memset(MSG_LEN,         0x00,   sizeof(MSG_LEN));

/*메시지 파싱*/
            memcpy(RECEIVER_ID,     msg[i].msg + pos,   32);
            pos += 32;
            
            memcpy(SENDER_ID,       msg[i].msg + pos,   32);
            pos += 32;
            
            memcpy(TIMEATAMP,       msg[i].msg + pos,   20);
            pos += 20;
            
            memcpy(TASK_GB,         msg[i].msg + pos,   32);
            pos += 32;
            
            memcpy(MSG_TITLE,       msg[i].msg + pos,   100);
            pos += 100;
            
            memcpy(NOTI_TYPE,       msg[i].msg + pos,   1);
            pos += 1;
            
            memcpy(LINK_GB,         msg[i].msg + pos,   1);
            pos += 1;
            
            if(LINK_GB[0] == 'Y')
            {
                memcpy(LINK_URL,    msg[i].msg + pos,   128);
                pos += 128;
            }
            
            memcpy(ATTACHFILE_CNT,  msg[i].msg + pos,   1);
            pos += 1;
            
            memcpy(ATTACHFILE_LEN,  msg[i].msg + pos,   4);
            pos += 4;
            
            mLen = atoi(ATTACHFILE_LEN);
            
            if(mLen > 0)
            {
                memcpy(ATTACHFILE_URL,  msg[i].msg + pos,   mLen);
                pos += mLen;
            }
            
            memcpy(MSG_LEN,         msg[i].msg + pos,   8);
            pos += 8;
            
            mLen = atoi(MSG_LEN);
            
            if(mLen > 0)
            {
                MSG_CTT = (char *)calloc(1,     mLen + 1);
                if(!MSG_CTT)
                {
                    printf("MSG_CTT Allocate Fail \n");
                    break;
                }
                
                memcpy(MSG_CTT,     msg[i].msg + pos,   mLen);
                pos += mLen;
            }
/*메시지 출력*/
            printf("RECEIVER_ID[%s]\n", RECEIVER_ID);
            printf("SENDER_ID[%s]\n", SENDER_ID);
            printf("TIMEATAMP [%s]\n",TIMEATAMP);
            printf("TASK_GB [%s]\n", TASK_GB);
            printf("MSG_TITLE [%s]\n",MSG_TITLE);
            printf("NOTI_TYPE [%s]\n",NOTI_TYPE);
            printf("LINK_GB[%s]\n",LINK_GB);
            printf("LINK_URL[%s]\n", LINK_URL);
            printf("ATTACHFILE_CNT [%s]\n",ATTACHFILE_CNT);
            printf("ATTACHFILE_LEN [%s] \n",ATTACHFILE_LEN);
            printf("MSG_LEN [%s]\n",MSG_LEN);
            printf("MSG_CTT[%s]\n", MSG_CTT);
            
            if(MSG_CTT)
            {
                free(MSG_CTT);
                MSG_CTT = NULL;
            }
            
            pos = 0;
            
            rtn = pushReceipt("114.205.98.48", 9901, "komj",  msg[i].msgid, 10);
            NSLog(@"pushReceipt rtn(%d)", rtn);
            
            if(msg[i].msg)
                free(msg[i].msg);
        }
    }
    
    if(msg)
        free(msg);
}

- (IBAction)pushGetMsgAll:(id)sender
{
    int rtn;
    
    DATA *msg = NULL;
    int recpCnt = 0;
    
    if( [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] || [[UIDevice currentDevice].model isEqualToString:@"iPad Simulator"] ){
        [DataManager sharedPCDataManager].deviceUUID = [[UIDevice currentDevice].identifierForVendor UUIDString];
    }
    else{
        [DataManager sharedPCDataManager].deviceUUID = [AppDelegate appDelegate].pushTokenID;
    }
    
    const char *token = [dataManager.deviceUUID UTF8String];
    
    if(token == NULL)
    {
        token = "testtoken";
    }

    rtn = pushGetMsgAll("211.255.202.76", 3101, "komj", "com.h2osystech.iMeritzService", token, 100, 10, &msg, &recpCnt);
    
    if(rtn < 0)
    {
        NSLog(@"getMsg(%d) 실패", rtn);
        
    }
    else if(rtn == 0)
    {
        NSLog(@"getMsg(%d) 메시지 없음", rtn);
    }
    else
    {
        int cnt = rtn;
        
        char    RECEIVER_ID     [32 + 1];
        char    SENDER_ID       [32 + 1];
        char    TIMEATAMP       [20 + 1];
        char    TASK_GB         [32 + 1];
        char    MSG_TITLE       [100+ 1];
        char    NOTI_TYPE       [1  + 1];
        char    LINK_GB         [1  + 1];
        char    LINK_URL        [128+ 1];
        char    ATTACHFILE_CNT  [1  + 1];
        char    ATTACHFILE_LEN  [4  + 1];
        char    ATTACHFILE_URL  [4000+1];
        char    MSG_LEN         [8  + 1];
        char    *MSG_CTT = NULL;
        int     pos = 0;
        int     mLen = 0;
        
        char    *seq_buff = NULL;
        int     seq_len = 0;
        int     rc = 0;
        seq_buff = calloc(1,    cnt * 18);
        if(seq_buff)
        {
            printf("allocation error\n");
        }
        
        NSLog(@"recpCnt[%d]", recpCnt);
        NSLog(@"cnt[%d]", cnt);
        for(int i=0; i<cnt; i++)
        {
            printf("############################[%d]###############################\n", i+1);
            NSLog(@"MSGID[%s]", msg[i].msgid);
            NSLog(@"MSGLen[%d]", msg[i].msgLen);
//            NSLog(@"MSG[%s]", msg[i].msg);
            
            memcpy(seq_buff + seq_len,  msg[i].msgid,   18);
            seq_len += 18;
            
            /*데이터저장 버퍼 초기화*/
            memset(RECEIVER_ID,     0x00,   sizeof(RECEIVER_ID));
            memset(SENDER_ID,       0x00,   sizeof(SENDER_ID));
            memset(TIMEATAMP,       0x00,   sizeof(TIMEATAMP));
            memset(TASK_GB,         0x00,   sizeof(TASK_GB));
            memset(MSG_TITLE,       0x00,   sizeof(MSG_TITLE));
            memset(NOTI_TYPE,       0x00,   sizeof(NOTI_TYPE));
            memset(LINK_GB,         0x00,   sizeof(LINK_GB));
            memset(LINK_URL,        0x00,   sizeof(LINK_URL));
            memset(ATTACHFILE_CNT,  0x00,   sizeof(ATTACHFILE_CNT));
            memset(ATTACHFILE_LEN,  0x00,   sizeof(ATTACHFILE_LEN));
            memset(ATTACHFILE_URL,  0x00,   sizeof(ATTACHFILE_URL));
            memset(MSG_LEN,         0x00,   sizeof(MSG_LEN));
            
            /*메시지 파싱*/
            memcpy(RECEIVER_ID,     msg[i].msg + pos,   32);
            pos += 32;
            
            memcpy(SENDER_ID,       msg[i].msg + pos,   32);
            pos += 32;
            
            memcpy(TIMEATAMP,       msg[i].msg + pos,   20);
            pos += 20;
            
            memcpy(TASK_GB,         msg[i].msg + pos,   32);
            pos += 32;
            
            memcpy(MSG_TITLE,       msg[i].msg + pos,   100);
            pos += 100;
            
            memcpy(NOTI_TYPE,       msg[i].msg + pos,   1);
            pos += 1;
            
            memcpy(LINK_GB,         msg[i].msg + pos,   1);
            pos += 1;
            
            if(LINK_GB[0] == 'Y')
            {
                memcpy(LINK_URL,    msg[i].msg + pos,   128);
                pos += 128;
            }
            
            memcpy(ATTACHFILE_CNT,  msg[i].msg + pos,   1);
            pos += 1;
            
            memcpy(ATTACHFILE_LEN,  msg[i].msg + pos,   4);
            pos += 4;
            
            mLen = atoi(ATTACHFILE_LEN);
            
            if(mLen > 0)
            {
                memcpy(ATTACHFILE_URL,  msg[i].msg + pos,   mLen);
                pos += mLen;
            }
            
            memcpy(MSG_LEN,         msg[i].msg + pos,   8);
            pos += 8;
            
            mLen = atoi(MSG_LEN);
            
            if(mLen > 0)
            {
                MSG_CTT = (char *)calloc(1,     mLen + 1);
                if(!MSG_CTT)
                {
                    printf("MSG_CTT Allocate Fail \n");
                    break;
                }
                
                memcpy(MSG_CTT,     msg[i].msg + pos,   mLen);
                pos += mLen;
            }
            /*메시지 출력*/

            printf("TIMEATAMP [%s]\n",TIMEATAMP);
            /*
            printf("RECEIVER_ID[%s]\n", RECEIVER_ID);
            printf("SENDER_ID[%s]\n", SENDER_ID);
            printf("TIMEATAMP [%s]\n",TIMEATAMP);
            printf("TASK_GB [%s]\n", TASK_GB);
            printf("MSG_TITLE [%s]\n",MSG_TITLE);
            
//            NSString *titl =[NSString stringWithUTF8String:(char *)MSG_TITLE];
//            NSLog(@"MSG_TITLE[%@]", titl);
            
            printf("NOTI_TYPE [%s]\n",NOTI_TYPE);
            printf("LINK_GB[%s]\n",LINK_GB);
            printf("LINK_URL[%s]\n", LINK_URL);
            printf("ATTACHFILE_CNT [%s]\n",ATTACHFILE_CNT);
            printf("ATTACHFILE_LEN [%s] \n",ATTACHFILE_LEN);
            printf("MSG_LEN [%s]\n",MSG_LEN);
            printf("MSG_CTT[%s]\n", MSG_CTT);
             */
//            NSString *ctt =[NSString stringWithUTF8String:(char *)MSG_CTT];
//            NSLog(@"MSG_CTT[%@]", ctt);
            
            if(MSG_CTT)
            {
                free(MSG_CTT);
                MSG_CTT = NULL;
            }
            
            pos = 0;

            if(msg[i].msg)
                free(msg[i].msg);
        }
        
        //수신확인 다중처리 API
        rc = pushReceiptMulti("211.255.202.76", 3101, "komj", (char *)token, seq_buff, seq_len, cnt);
        if(rc<=0)
        {
            printf("pushReceiptMulti rc(%d)\n", rc);
        }
        else
        {
            printf("pushReceiptMulti rc(%d)\n", rc);
        }
        
        if(seq_buff)
            free(seq_buff);
    }
    
    NSLog(@"pushGetMsg END");
    
    if(msg)
    {
        free(msg);
    }
}

- (IBAction)pushGetMsg_idx:(id)sender
{
    int rtn;
    
    int rLen = 0;
    char *rtnMsg = NULL;
    char rtnMsgIdx[18];
    memset(rtnMsgIdx, 0x00, sizeof(rtnMsgIdx));
    
    char *msgid="201512310000000025";
    
    rtn = pushGetMsg_idx("114.205.98.48", 14101, "komj", "kr.co.srail.smt", msgid, 10, &rtnMsg, &rLen, rtnMsgIdx);
    if(rtn < 0)
    {
        NSLog(@"getMsg(%d)", rtn);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"pushGetMsg_idx 실패" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
        
    }
    else if(rtn > 0)
    {
        NSLog(@"getMsg(%d)", rtn);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"미수신 메시지가 없습니다." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        
        [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
    }
    else
    {
        NSLog(@"getMsg(%s)", rtnMsg);
        NSLog(@"MsgLen(%d)", rLen);
        NSLog(@"MsgIdx(%s)", rtnMsgIdx);
    }
    
    if(rtnMsg)
        free(rtnMsg);
}

@end
