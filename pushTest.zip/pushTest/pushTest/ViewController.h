//
//  ViewController.h
//  pushTest
//
//  Created by komj on 2015. 3. 12..
//  Copyright (c) 2015년 H2OSystech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ViewController : UIViewController <NSStreamDelegate, UIAlertViewDelegate>
{
    
}

-(IBAction)pushRegist:(id)sender;
-(IBAction)pushUnRegist:(id)sender;
-(IBAction)pushReceipt:(id)sender;
-(IBAction)pushGetMsg:(id)sender;
-(IBAction)pushGetMsgAll:(id)sender;
@end

