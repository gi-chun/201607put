package com.example.sb_sk;


import com.h2osystech.smartalimi.aidllib.MSGVo;
import com.h2osystech.smartalimi.aidllib.SmartAgentInterface;
import com.h2osystech.smartalimi.servicealimi.AlimiInterface;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MsgReadActivity extends Activity {
	SmartAgentInterface agent;
	MSGVo vo;
	TextView tv_UnicSeq, tv_MsgYn, tv_TimeStamp, tv_NotiCd, tv_HtmlYN, tv_Content, tv_Url, tv_getSenderBySeq;
	TextView tv_getReadMSG;
	TextView tv_ContactName;
	TextView tv_Sender, tv_Attachfile, tv_Downfileurl, tv_NewMsgcnt, tv_TaskCode, tv_Attachfilecnt;
	EditText et_setName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_msg_read);

		tv_UnicSeq = (TextView) findViewById(R.id.UnicSeq);
		tv_MsgYn = (TextView) findViewById(R.id.MsgYn);
		tv_TimeStamp = (TextView) findViewById(R.id.TimeStamp);
		tv_NotiCd = (TextView) findViewById(R.id.NotiCd);
		tv_HtmlYN = (TextView) findViewById(R.id.HtmlYN);
		tv_Content = (TextView) findViewById(R.id.Content);
		tv_Url = (TextView) findViewById(R.id.Url);
		tv_Sender = (TextView) findViewById(R.id.Sender);
		tv_Attachfile = (TextView) findViewById(R.id.Attachfile);
		tv_Downfileurl = (TextView) findViewById(R.id.Downfileurl);
		tv_NewMsgcnt = (TextView) findViewById(R.id.NewMsgcnt);
		tv_TaskCode = (TextView) findViewById(R.id.TaskCode);
		tv_Attachfilecnt = (TextView) findViewById(R.id.Attachfilecnt);
		tv_ContactName = (TextView) findViewById(R.id.ContactName);
		tv_getReadMSG = (TextView) findViewById(R.id.tv_getReadMSG);
		

		String UnicSeq = "";

		try {
			agent = MainActivity.agent;
			
			Bundle extras = getIntent().getExtras();
			if (extras == null) {

			} else {
				Log.d("aaaa2=======================================", UnicSeq);
				vo = (MSGVo)extras.getParcelable("vo");
			}
			NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			
			Log.d("aaaa3=======================================", vo.getUniqSeq());
			tv_UnicSeq.setText("UnicSeq : " + vo.getUniqSeq());
			
			String time = vo.getTimeStamp();
			time= time.substring(0,4)+"/"+time.substring(4, 6)+"/"+time.substring(6, 8)+" "+time.substring(8, 10)+":"+time.substring(10, 12)+":"+time.substring(12, 14);
			
			tv_TimeStamp.setText("TimeStamp : " + time);
			tv_NotiCd.setText("NotiCd : " + vo.getNotiType()+"    ServerSeq = "+vo.getSeq());
			
			tv_Content.setText("Content : " + vo.getContent());
			tv_Url.setText("Url : " + vo.getUrl());
			tv_Sender.setText("Sender : " + vo.getSender());
			tv_Attachfile.setText("Attachfile : " + vo.getAttachfile());
			
			tv_NewMsgcnt.setText("NewMsgcnt : " + vo.getNewMsgCnt());
			tv_Attachfilecnt.setText("Attachfilecnt : " + String.valueOf(vo.getAttachfileCnt()));
			tv_ContactName.setText("ContactName : " + vo.getContactName());
		} catch (Exception e) {
			Log.d("aaaa4=======================================", vo.getUniqSeq());
			vo = null;
			Toast toast = Toast.makeText(MsgReadActivity.this, "getUnicMsg����  " + e, Toast.LENGTH_LONG);
			toast.show();
		}
		

	}
}
