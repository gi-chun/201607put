package com.example.sb_sk;

import java.util.ArrayList;

import com.h2osystech.smartalimi.aidllib.MSGVo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
 
public class CustomAdapter extends BaseAdapter {
     
    private ArrayList<MSGVo>   m_List;
     
    public CustomAdapter(ArrayList<MSGVo> volist) {
        m_List = volist;
    }
 
 
    @Override
    public int getCount() {
        return m_List.size();
    }
 
   
    @Override
    public Object getItem(int position) {
        return m_List.get(position);
    }
 

    @Override
    public long getItemId(int position) {
        return position;
    }
 
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.msg, parent, false);
             
            TextView UnicSeq = (TextView) convertView.findViewById(R.id.NotiCd);
            UnicSeq.setText(m_List.get(position).getSender());
             
   
            TextView Content = (TextView) convertView.findViewById(R.id.Content);
            Content.setText(m_List.get(position).getContent());
            
            TextView tv_Date= (TextView) convertView.findViewById(R.id.tv_Date);
            
            String date=m_List.get(position).getUniqSeq();
            date=date.substring(0, 8);
            //date=date.substring(0,4)+"/"+date.substring(4,6)+"/"+date.substring(6,8);
            tv_Date.setText(date);
            
         
        return convertView;
    }
     
    public void add(MSGVo _msg) {
        m_List.add(_msg);
    }
   
    
    public void remove(int _position) {
        m_List.remove(_position);
    }
}