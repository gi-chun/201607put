package com.example.sb_sk;

import java.util.ArrayList;
import java.util.List;

import com.h2osystech.smartalimi.aidllib.MSGVo;
import com.h2osystech.smartalimi.aidllib.SmartAgentInterface;
import com.h2osystech.smartalimi.common.Const;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MsgListActivity extends Activity {
	SmartAgentInterface agent;
	CustomAdapter m_Adapter;
	ListView lv_view;
	ArrayList<MSGVo> msg_list;
	Button btn_count;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_msg_list);

		agent = MainActivity.agent;

		msg_list = new ArrayList<MSGVo>();

		try {
			if (agent.getAllMsg() != null){
				msg_list = (ArrayList<MSGVo>) agent.getAllMsg();

				m_Adapter = new CustomAdapter(msg_list);
			}
		} catch (Exception e) {
			Toast toast = Toast.makeText(MsgListActivity.this, "getAllMSG����  " + e, Toast.LENGTH_LONG);
			toast.show();
		}

		btn_count = (Button) findViewById(R.id.btn_count);
		lv_view = (ListView) findViewById(R.id.all_list);
		lv_view.setAdapter(m_Adapter);
		m_Adapter.notifyDataSetChanged();


		OnItemClickListener listener = new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				try {
					 
					 Intent intent = new Intent(getApplicationContext(), MsgReadActivity.class);
		       		 intent.putExtra("vo", msg_list.get(position));
		             startActivity(intent);
		             
				} catch (Exception e) {
					Toast toast = Toast.makeText(MsgListActivity.this, "���� " + e, Toast.LENGTH_LONG);
					toast.show();
				}
			}
		};

		lv_view.setOnItemClickListener(listener);

		btn_count.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					Toast.makeText(getApplicationContext(), "Adapter Cnt : "+m_Adapter.getCount()+"DB Cnt : "+agent.getAllMsg().size(), Toast.LENGTH_LONG).show();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		BroadcastReceiver newMsgReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				// ȭ�� ���� ó�� or �޽��� ���� signal
				String uniseq = intent.getStringExtra("uniseq");
				// Custom�˸� ����
				msg_list.clear();
				
				/*
				lv_view.removeAllViews();
				*/
				try {
					if (agent.getAllMsg() != null)
						msg_list = (ArrayList<MSGVo>) agent.getAllMsg();
				} catch (Exception e) {
					Toast toast = Toast.makeText(MsgListActivity.this, "getAllMSG����  " + e, Toast.LENGTH_LONG);
					toast.show();
				}

				m_Adapter = new CustomAdapter(msg_list);
				lv_view.setAdapter(m_Adapter);
				m_Adapter.notifyDataSetChanged();
			}
		};

		try {
			IntentFilter newMsgFilter = new IntentFilter(Const.readAgentRefreshNewMSGReceiver(MsgListActivity.this));
			MsgListActivity.this.registerReceiver(newMsgReceiver, newMsgFilter);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}
	
}
