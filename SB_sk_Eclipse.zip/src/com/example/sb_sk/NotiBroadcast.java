package com.example.sb_sk;

import com.h2osystech.smartalimi.aidllib.MSGVo;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.PowerManager;
import android.os.RemoteException;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

public class NotiBroadcast extends BroadcastReceiver{
	
	@Override
	public void onReceive(android.content.Context context, android.content.Intent intent) {

		MSGVo vo = (MSGVo)intent.getParcelableExtra("msg");
		
		Log.d("broadcast", "is null?"+ vo.getUniqSeq());
		// Custom�˸� ����
		
		NotificationSomethins1(vo,context);
		
	};
public void NotificationSomethins1(MSGVo vo,Context context) {  
	    
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);  
        nm.cancel(1234);
        Resources res = context.getResources();  
    
        Intent notificationIntent = new Intent(context, MsgReadActivity.class);  
        notificationIntent.putExtra("vo", vo); //������ ��
        
        Log.d("aaaa1=======================================", vo.getUniqSeq());
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);  
    
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Log.d("uriaasdas", uri.toString());
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)  
                .setContentTitle(vo.getTitle())  
                .setContentText(vo.getContent())  
                .setTicker(vo.getDate())  
                .setSmallIcon(R.drawable.ic_launcher)   
                .setContentIntent(contentIntent)  
                .setAutoCancel(true)  
                .setWhen(System.currentTimeMillis())    
                .setNumber(13);  
        
        builder.setSound(uri);

			PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
			PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK |
			        PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, context.getClass().getName());
			wl.acquire(3000);
			        
        
        Notification  n = builder.build();
        nm.notify(1234, n);  
    }
}
