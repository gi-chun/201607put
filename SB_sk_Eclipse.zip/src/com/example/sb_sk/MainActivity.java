package com.example.sb_sk;


import com.h2osystech.smartalimi.aidllib.SmartAgentInterface;
import com.h2osystech.smartalimi.common.Const;
import com.h2osystech.smartalimi.servicealimi.MessageManager;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
	Context context;
	static SmartAgentInterface agent;
	ServiceConnection conn;

	Button btn_Login, btn_Close;
	EditText et_LoginID, et_LoginPassword;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		alimi_Init();
	
		btn_Login = (Button) findViewById(R.id.btn_Login);
		btn_Close = (Button) findViewById(R.id.btn_Close);
		et_LoginID = (EditText) findViewById(R.id.et_LoginID);
		et_LoginPassword = (EditText) findViewById(R.id.et_LoginPassword);
		
		btn_Login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String id = et_LoginID.getText().toString();
				String pass = et_LoginPassword.getText().toString();

				int result = -1;
				try {
					agent.setServerIPPort("114.205.98.48", "5101");
					agent.setBedgeCountPackage(getPackageName()+".MainActivity");

					result = agent.setLogin(id, pass, 1);
					if (result >= 0) {
						Toast toast = Toast.makeText(MainActivity.this, "�α��� ���� " + result, Toast.LENGTH_LONG);
						toast.show();
						
						Intent intent = new Intent(getApplicationContext(), MsgListActivity.class);
						startActivity(intent);
						
					}
				} catch (Exception e) {
					Toast toast = Toast.makeText(MainActivity.this, "�α��� ���� " + result + " " + e, Toast.LENGTH_LONG);
					toast.show();
				}

			}
		});
	}

	private void alimi_Init() {
		
		context = getApplicationContext();

		conn = new ServiceConnection() {
			@Override
			public void onServiceConnected(ComponentName name, IBinder service) {
				int result = -1;
				try {
					
					agent = SmartAgentInterface.Stub.asInterface(service, context);
					
					Toast toast = Toast.makeText(MainActivity.this, "Ŀ��Ʈ ����", Toast.LENGTH_LONG);
					toast.show();
				} catch (Exception e) {
					Toast toast = Toast.makeText(MainActivity.this, "Ŀ��Ʈ ����" + e, Toast.LENGTH_LONG);
					toast.show();
				}
			}

			@Override
			public void onServiceDisconnected(ComponentName name) {
				agent = null;
			}
		};
		
		Intent intent = new Intent(this,MessageManager.class);

		bindService(intent, conn, BIND_AUTO_CREATE);
	}
	
	@Override
	protected void onDestroy() {
			unbindService(conn);
		super.onDestroy();
	}
}
